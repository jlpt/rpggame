var images = new Array()
images[0] = new Image()
images[0].src = "Images/Frame.png"

images[1] = new Image()
images[1].src = 'Images/Sword.png'

images[2] = new Image()
images[2].src = 'Images/Shield.png'

images[3] = new Image()
images[3].src = 'Images/HealthPot.png'

images[4] = new Image()
images[4].src = 'Images/ManaPot.png'

images[5] = new Image()
images[5].src = 'Images/Warrior.png'

images[6] = new Image()
images[6].src = 'Images/Grass.jpg'

images[7] = new Image()
images[7].src = 'Images/Empty.png'

images[8] = new Image()
images[8].src = 'Images/Warrior2.png'

images[9] = new Image()
images[9].src = 'Images/PlayerBullet.png'

images[10] = new Image()
images[10].src = 'Images/Slime.png'

images[11] = new Image()
images[11].src = 'Images/DONKEYKONG.png'

images[12] = new Image()
images[12].src = 'Images/smallkong.png'

images[13] = new Image()
images[13].src = 'Images/mountainmen2.png'

images[14] = new Image()
images[14].src = 'Images/cringeyaf.jpg'

images[15] = new Image()
images[15].src = 'Images/SuperPot.png'